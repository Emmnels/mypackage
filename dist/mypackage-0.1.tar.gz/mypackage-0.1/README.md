**describe our package in more detail**. 

> Go to [this website](https://www.makeareadme.com/) for some helpful info on how to make a proper README file.

<img src="https://github.com/James-Leslie/example-python-package/blob/master/images/4.0_readme.png?raw=true" alt="Completed code in Atom" style="width: 65%;"/>